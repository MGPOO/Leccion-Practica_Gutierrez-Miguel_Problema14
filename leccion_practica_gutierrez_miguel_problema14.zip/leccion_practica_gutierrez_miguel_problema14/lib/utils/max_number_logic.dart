class MaxNumberLogic {
  static String findMaxNumber(String input1, String input2, String input3) {
    try {

      final num1 = double.parse(input1);
      final num2 = double.parse(input2);
      final num3 = double.parse(input3);


      double maxNumber = num1 > num2
          ? (num1 > num3 ? num1 : num3)
          : (num2 > num3 ? num2 : num3);

      return 'El número mayor es: $maxNumber';
    } catch (e) {
      return 'Por favor, ingresa números válidos.';
    }
  }
}
