import 'package:flutter/material.dart';
import '../utils/max_number_logic.dart';

class MaxNumberApp extends StatefulWidget {
  @override
  _MaxNumberAppState createState() => _MaxNumberAppState();
}

class _MaxNumberAppState extends State<MaxNumberApp> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  final TextEditingController _controller3 = TextEditingController();
  String _result = '';

  void _calculateMax() {
    if (_isValidInput(_controller1.text) &&
        _isValidInput(_controller2.text) &&
        _isValidInput(_controller3.text)) {
      setState(() {
        _result = MaxNumberLogic.findMaxNumber(
          _controller1.text,
          _controller2.text,
          _controller3.text,
        );
      });
    } else {
      setState(() {
        _result = 'Por favor, ingresa solo números válidos.';
      });
    }
  }

  bool _isValidInput(String input) {
    final numberRegex = RegExp(r'^[0-9]+(\.[0-9]+)?$'); // Permite números enteros o decimales
    return numberRegex.hasMatch(input);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Encuentra el Número Mayor',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ingresa tres números diferentes:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.filter_1, color: Colors.blueAccent, size: 28),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _controller1,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Primer número',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.filter_2, color: Colors.green, size: 28),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _controller2,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Segundo número',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.filter_3, color: Colors.orange, size: 28),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _controller3,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Tercer número',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: _calculateMax,
                icon: Icon(Icons.calculate, size: 24),
                label: Text('Calcular'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent, // Corrección aquí
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  textStyle:
                  TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 30),
            Center(
              child: Text(
                _result,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
